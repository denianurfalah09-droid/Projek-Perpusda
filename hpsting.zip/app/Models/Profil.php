<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Profil extends Model
{
    use HasFactory;

    protected $table = 'profil';

    public $timestamps = false;

    protected $fillable = [
        'judul',
        'isi',
        'gambar',
    ];
}


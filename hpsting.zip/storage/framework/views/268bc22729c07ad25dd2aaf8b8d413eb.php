<?php $__env->startSection('title', 'Katalog Buku - Perpustakaan Daerah Kabupaten Purwakarta'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/katalog.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- ================= BANNER HEADER KATALOG ================= -->
<section class="katalog-hero-banner">
    <div class="site-container">
        <div class="katalog-banner-content">
            <div class="katalog-breadcrumb">
                <a href="<?php echo e(route('beranda')); ?>">Beranda</a>
                <span>/</span>
                <span>Katalog Koleksi Buku</span>
            </div>
            <h1>Koleksi Buku Perpustakaan</h1>
            <p>Telusuri dan temukan berbagai judul buku bacaan, literatur ilmiah, buku pelajaran, dan karya sejarah di Perpusda Purwakarta.</p>

            <!-- SEARCH & FILTER FORM -->
            <form action="<?php echo e(route('katalog')); ?>" method="GET" class="katalog-search-form">
                <?php if(request('kategori')): ?>
                    <input type="hidden" name="kategori" value="<?php echo e(request('kategori')); ?>">
                <?php endif; ?>
                <div class="katalog-search-input-box">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari judul buku, pengarang, penerbit, atau kata kunci..." aria-label="Cari koleksi buku">
                    <?php if(request('search')): ?>
                        <a href="<?php echo e(route('katalog', request()->except('search'))); ?>" class="btn-clear-search" title="Hapus pencarian">&times;</a>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn-submit-search">
                    <span>Cari Buku</span>
                </button>
            </form>
        </div>
    </div>
</section>


<!-- ================= KONTEN UTAMA KATALOG ================= -->
<section class="katalog-main-section">
    <div class="site-container">

        <!-- FILTER KATEGORI PILLS -->
        <div class="category-filter-nav">
            <span class="filter-label">Filter Kategori:</span>
            <div class="filter-pills-list">
                <a href="<?php echo e(route('katalog', request()->only('search'))); ?>" 
                   class="filter-pill <?php echo e(!request('kategori') ? 'active' : ''); ?>">
                    Semua Koleksi
                </a>
                <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $katName = is_object($kat) ? $kat->nama_kategori : $kat;
                    ?>
                    <?php if($katName !== 'Semua'): ?>
                        <a href="<?php echo e(route('katalog', array_merge(request()->only('search'), ['kategori' => $katName]))); ?>" 
                           class="filter-pill <?php echo e(request('kategori') == $katName ? 'active' : ''); ?>">
                            <?php echo e($katName); ?>

                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- INFO BAR HASIL & RESET -->
        <div class="katalog-info-bar">
            <div class="results-count">
                Menampilkan <strong><?php echo e($buku->firstItem() ?? 0); ?> - <?php echo e($buku->lastItem() ?? 0); ?></strong> dari <strong><?php echo e($buku->total()); ?></strong> buku
                <?php if(request('kategori')): ?>
                    dalam kategori <span class="tag-active-filter">"<?php echo e(request('kategori')); ?>"</span>
                <?php endif; ?>
                <?php if(request('search')): ?>
                    dengan kata kunci <span class="tag-active-filter">"<?php echo e(request('search')); ?>"</span>
                <?php endif; ?>
            </div>

            <?php if(request('kategori') || request('search')): ?>
                <a href="<?php echo e(route('katalog')); ?>" class="btn-reset-all-filters">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                    <span>Reset Semua Filter</span>
                </a>
            <?php endif; ?>
        </div>

        <!-- GRID DAFTAR BUKU -->
        <div class="katalog-books-grid">
            <?php $__empty_1 = true; $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="catalog-book-card">
                    <div class="book-card-cover-wrapper">
                        <?php if($item->gambar && file_exists(public_path('uploads/katalog/' . $item->gambar))): ?>
                            <img src="<?php echo e(asset('uploads/katalog/' . $item->gambar)); ?>" alt="<?php echo e($item->judul); ?>" class="catalog-cover-img" loading="lazy">
                        <?php else: ?>
                            <div class="catalog-cover-fallback">
                                <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
                                    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
                                </svg>
                                <span class="fallback-book-text"><?php echo e(\Illuminate\Support\Str::limit($item->judul, 25)); ?></span>
                            </div>
                        <?php endif; ?>
                        <span class="category-pill-badge"><?php echo e($item->kategori); ?></span>
                    </div>

                    <div class="book-card-body">
                        <h2 class="book-title-heading" title="<?php echo e($item->judul); ?>">
                            <?php echo e($item->judul); ?>

                        </h2>

                        <div class="book-detail-list">
                            <div class="detail-row">
                                <span class="detail-label">Penulis</span>
                                <span class="detail-val" title="<?php echo e($item->penulis); ?>"><?php echo e($item->penulis); ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Penerbit</span>
                                <span class="detail-val" title="<?php echo e($item->penerbit); ?>"><?php echo e($item->penerbit); ?></span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">Tahun</span>
                                <span class="detail-val"><?php echo e($item->tahun); ?></span>
                            </div>
                        </div>

                        <div class="book-card-action">
                            <span class="badge-status-ready">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                Tersedia di Rak
                            </span>
                            <span class="pinjam-info-hint">Pinjam di Perpusda</span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="katalog-empty-state">
                    <div class="empty-icon-box">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="11" cy="11" r="8"></circle>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                        </svg>
                    </div>
                    <h3>Buku Tidak Ditemukan</h3>
                    <p>Maaf, tidak ada koleksi buku yang cocok dengan kriteria filter atau pencarian Anda.</p>
                    <a href="<?php echo e(route('katalog')); ?>" class="btn-primary" style="margin-top: 1rem;">
                        <span>Kembali ke Semua Koleksi</span>
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- ================= PAGINATION ================= -->
        <?php if($buku->hasPages()): ?>
            <div class="katalog-pagination-wrapper">
                <nav class="custom-pagination" role="navigation" aria-label="Navigasi Halaman Buku">
                    
                    <?php if($buku->onFirstPage()): ?>
                        <span class="page-link disabled" aria-disabled="true">&laquo; Sebelumnya</span>
                    <?php else: ?>
                        <a href="<?php echo e($buku->previousPageUrl()); ?>" class="page-link" rel="prev">&laquo; Sebelumnya</a>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $buku->getUrlRange(1, $buku->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $buku->currentPage()): ?>
                            <span class="page-link active" aria-current="page"><?php echo e($page); ?></span>
                        <?php else: ?>
                            <a href="<?php echo e($url); ?>" class="page-link"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($buku->hasMorePages()): ?>
                        <a href="<?php echo e($buku->nextPageUrl()); ?>" class="page-link" rel="next">Berikutnya &raquo;</a>
                    <?php else: ?>
                        <span class="page-link disabled" aria-disabled="true">Berikutnya &raquo;</span>
                    <?php endif; ?>
                </nav>
            </div>
        <?php endif; ?>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Projek-Perpusda\resources\views/katalog.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Kategori Buku'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-title">
    <div>
        <h1>Kategori Buku</h1>
        <p>Kelola klasifikasi dan pengkategorian koleksi buku perpustakaan</p>
    </div>

    <div class="page-title-actions">
        <a href="<?php echo e(route('admin.kategori.create')); ?>" class="btn-primary">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            <span>Tambah Kategori Baru</span>
        </a>
    </div>
</div>

<div class="table-card">

    <div class="table-card-header">
        <div class="table-card-title">
            <h3>Daftar Kategori</h3>
            <span class="badge-count"><?php echo e($kategori->total()); ?> Kategori</span>
        </div>
    </div>

    <div class="table-container">

        <table class="admin-table kategori-table">

            <thead>
                <tr>
                    <th style="width: 50px;">No</th>
                    <th style="width: 70px; text-align: center;">Icon</th>
                    <th>Nama Kategori</th>
                    <th>Slug</th>
                    <th>Jumlah Koleksi Buku</th>
                    <th style="width: 110px; text-align: center;">Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center font-medium"><?php echo e(($kategori->currentPage() - 1) * $kategori->perPage() + $index + 1); ?></td>
                        <td style="text-align: center; font-size: 20px;"><?php echo e($item->icon ?? '📚'); ?></td>
                        <td>
                            <strong style="color: #0048a8;"><?php echo e($item->nama_kategori); ?></strong>
                            <?php if($item->deskripsi): ?>
                                <div style="font-size: 0.8rem; color: #64748b; margin-top: 2px;"><?php echo e($item->deskripsi); ?></div>
                            <?php endif; ?>
                        </td>
                        <td><code><?php echo e($item->slug); ?></code></td>
                        <td>
                            <span class="badge-count"><?php echo e($item->buku_count ?? 0); ?> Buku</span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <a href="<?php echo e(route('admin.kategori.edit', $item->id)); ?>" class="btn-action btn-edit" title="Edit Kategori">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                                </a>

                                <form action="<?php echo e(route('admin.kategori.destroy', $item->id)); ?>" method="POST" class="form-delete-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus kategori \'<?php echo e(addslashes($item->nama_kategori)); ?>\'?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-action btn-delete" title="Hapus Kategori">
                                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-5">
                            <div class="empty-table-state">
                                <p>Belum ada kategori yang terdaftar.</p>
                                <a href="<?php echo e(route('admin.kategori.create')); ?>" class="btn-primary" style="margin-top: 10px;">
                                    + Tambah Kategori
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>

        </table>

    </div>

    <?php if($kategori->hasPages()): ?>
        <div style="padding: 1.25rem 1.5rem; display: flex; align-items: center; justify-content: space-between; border-top: 1px solid #f1f5f9; flex-wrap: wrap; gap: 1rem;">
            <div style="font-size: 0.88rem; color: #64748b;">
                Menampilkan <strong><?php echo e($kategori->firstItem() ?? 0); ?> - <?php echo e($kategori->lastItem() ?? 0); ?></strong> dari <strong><?php echo e($kategori->total()); ?></strong> kategori
            </div>

            <div style="display: flex; gap: 6px;">
                <?php if($kategori->onFirstPage()): ?>
                    <span style="padding: 6px 12px; background: #f1f5f9; color: #94a3b8; border-radius: 6px; font-size: 0.85rem; cursor: not-allowed;">&laquo; Sebelumnya</span>
                <?php else: ?>
                    <a href="<?php echo e($kategori->previousPageUrl()); ?>" style="padding: 6px 12px; background: #ebf4ff; color: #0048a8; border-radius: 6px; font-size: 0.85rem; font-weight: 700; text-decoration: none;">&laquo; Sebelumnya</a>
                <?php endif; ?>

                <?php $__currentLoopData = $kategori->getUrlRange(1, $kategori->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $kategori->currentPage()): ?>
                        <span style="padding: 6px 12px; background: #0048a8; color: white; border-radius: 6px; font-size: 0.85rem; font-weight: 700;"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>" style="padding: 6px 12px; background: #f8fafc; color: #334155; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.85rem; text-decoration: none;"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($kategori->hasMorePages()): ?>
                    <a href="<?php echo e($kategori->nextPageUrl()); ?>" style="padding: 6px 12px; background: #ebf4ff; color: #0048a8; border-radius: 6px; font-size: 0.85rem; font-weight: 700; text-decoration: none;">Berikutnya &raquo;</a>
                <?php else: ?>
                    <span style="padding: 6px 12px; background: #f1f5f9; color: #94a3b8; border-radius: 6px; font-size: 0.85rem; cursor: not-allowed;">Berikutnya &raquo;</span>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Projek-Perpusda\resources\views/admin/kategori/index.blade.php ENDPATH**/ ?>
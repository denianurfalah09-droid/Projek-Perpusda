

<?php $__env->startSection('title', 'Tambah Berita'); ?>

<?php $__env->startSection('breadcrumb', 'Berita / Tambah Berita'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-title">
    <h1>Tambah Berita</h1>
    <p>Beranda / Berita / Tambah Berita</p>
</div>

<form
    action="<?php echo e(route('admin.berita.store')); ?>"
    method="POST"
    enctype="multipart/form-data"
    class="form-container berita-form"
>
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="judul">Judul Berita</label>

        <input
            type="text"
            id="judul"
            name="judul"
            placeholder="Masukkan judul berita"
            value="<?php echo e(old('judul')); ?>"
        >
    </div>

    <div class="form-group">
        <label for="link">Link Berita</label>

        <input
            type="url"
            id="link"
            name="link"
            placeholder="Masukkan link berita"
            value="<?php echo e(old('link')); ?>"
        >
    </div>

    <div class="form-group">
        <label for="tanggal">Tanggal</label>

        <input
            type="date"
            id="tanggal"
            name="tanggal"
            value="<?php echo e(old('tanggal')); ?>"
        >
    </div>

    <div class="form-group">
        <label for="gambar">Gambar Berita</label>

        <input
            type="file"
            id="gambar"
            name="gambar"
        >
    </div>

    <div class="form-actions">

        <a href="<?php echo e(route('admin.berita')); ?>" class="btn-cancel">
            Batal
        </a>

        <button type="submit" class="btn-save">
            Simpan
        </button>

    </div>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Projek-Perpusda\resources\views/admin/berita/create.blade.php ENDPATH**/ ?>
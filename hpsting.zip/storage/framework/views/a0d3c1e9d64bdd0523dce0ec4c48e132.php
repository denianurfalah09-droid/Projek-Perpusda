

<?php $__env->startSection('title', 'Berita'); ?>
<?php $__env->startSection('breadcrumb', 'Beranda / Berita'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-title">
    <h1>Berita</h1>
    <p>Beranda / Berita</p>
</div>

<div class="berita-header">
    <a href="<?php echo e(route('admin.berita.create')); ?>" class="btn-primary">
        +&nbsp; Tambah Berita
    </a>
</div>

<div class="table-container">

    <table class="admin-table berita-table">

        <thead>
            <tr>
                <th>NO</th>
                <th>Judul</th>
                <th>Tanggal</th>
                <th>Gambar</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr>
                    <td><?php echo e($loop->iteration); ?></td>

                    <td>
                        <?php echo e($item->judul); ?>

                    </td>

                    <td>
                        <?php echo e(\Carbon\Carbon::parse($item->tanggal)->format('d F Y')); ?>

                    </td>

                    <td>
                        <?php if($item->gambar): ?>
                            <img
                                src="<?php echo e(asset('images/' . $item->gambar)); ?>"
                                alt="<?php echo e($item->judul); ?>"
                                class="berita-image"
                            >
                        <?php else: ?>
                            <div class="berita-image-placeholder">
                                Gambar
                            </div>
                        <?php endif; ?>
                    </td>

                    <td>
                        <div class="action-buttons">

                            <a
                                href="<?php echo e(route('admin.berita.edit', $item->id)); ?>"
                                class="btn-edit"
                                title="Edit"
                            >
                                ✎
                            </a>

                            <button
                                type="button"
                                class="btn-delete"
                                title="Hapus"
                            >
                                ×
                            </button>

                        </div>
                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>
                    <td colspan="5" style="text-align:center; padding:30px;">
                        Belum ada berita.
                    </td>
                </tr>

            <?php endif; ?>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Projek-Perpusda\resources\views/admin/berita/index.blade.php ENDPATH**/ ?>
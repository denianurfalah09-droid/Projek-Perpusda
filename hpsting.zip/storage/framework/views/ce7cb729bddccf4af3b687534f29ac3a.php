

<?php $__env->startSection('title', 'Tambah User'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-title">
    <h1>Tambah User</h1>
    <p>Beranda / User / Tambah User</p>
</div>

<div class="user-form">

    <div class="user-form-group">

        <label for="username">
            Username
        </label>

        <input
            type="text"
            id="username"
            name="username"
            placeholder="Masukan username"
        >

    </div>


    <div class="user-form-group">

        <label for="email">
            Email
        </label>

        <input
            type="email"
            id="email"
            name="email"
            placeholder="Masukan email"
        >

    </div>


    <div class="user-form-group">

        <label for="password">
            Password
        </label>

        <input
            type="password"
            id="password"
            name="password"
            placeholder="Masukan password"
        >

    </div>


    <div class="user-form-actions">

        <a
            href="<?php echo e(route('admin.user')); ?>"
            class="user-btn-cancel"
        >
            Batal
        </a>

        <button
            type="submit"
            class="user-btn-save"
        >
            Simpan
        </button>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Projek-Perpusda\resources\views/admin/user/create.blade.php ENDPATH**/ ?>
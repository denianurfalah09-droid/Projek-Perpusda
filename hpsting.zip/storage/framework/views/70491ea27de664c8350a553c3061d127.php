<?php $__env->startSection('title', 'Kategori Buku - Perpustakaan Daerah Kabupaten Purwakarta'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/kategori.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- ================= BANNER HEADER KATEGORI ================= -->
<section class="kategori-hero-banner">
    <div class="site-container">
        <div class="kategori-banner-content">
            <div class="kategori-breadcrumb">
                <a href="<?php echo e(route('beranda')); ?>">Beranda</a>
                <span>/</span>
                <span>Kategori Buku</span>
            </div>
            <h1>Klasifikasi Kategori Buku</h1>
            <p>Pilih kategori literatur yang Anda inginkan untuk menemukan buku-buku terbaik di Perpustakaan Daerah Purwakarta.</p>
        </div>
    </div>
</section>

<!-- ================= DAFTAR KATEGORI ================= -->
<section class="kategori-list-section">
    <div class="site-container">

        <div class="kategori-section-header">
            <div>
                <h2>Semua Kategori Koleksi</h2>
                <p>Temukan ratusan buku menarik berdasarkan klasifikasi bidang keilmuan</p>
            </div>
            <a href="<?php echo e(route('katalog')); ?>" class="btn-view-all-katalog">
                <span>Buka Seluruh Katalog &rarr;</span>
            </a>
        </div>

        <div class="kategori-cards-grid">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('katalog', ['kategori' => $cat->nama_kategori])); ?>" class="kategori-box-card">
                    <div class="kategori-box-top">
                        <div class="kategori-box-icon">
                            <?php echo e($cat->icon ?? '📖'); ?>

                        </div>
                        <span class="kategori-count-badge">
                            <?php echo e($cat->buku_count ?? 0); ?> Buku
                        </span>
                    </div>

                    <div class="kategori-box-body">
                        <h3><?php echo e($cat->nama_kategori); ?></h3>
                        <p><?php echo e($cat->deskripsi ?? 'Kumpulan koleksi buku pilihan dalam kategori ' . $cat->nama_kategori . '.'); ?></p>
                    </div>

                    <div class="kategori-box-footer">
                        <span class="view-books-text">Jelajahi Koleksi</span>
                        <div class="arrow-circle">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Projek-Perpusda\resources\views/kategori.blade.php ENDPATH**/ ?>